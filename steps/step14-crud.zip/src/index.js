import { Component } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';

class MainApp extends Component{
    state = {
        users : [],
        adduser : false,
        showEditForm : false,
        firstname : '',
        lastname : '',
        email : '',
        age : '',
        edit_firstname : '',
        edit_lastname : '',
        edit_email : '',
        edit_age : '',
        edit_id : '',
    }
    dataurl = "http://localhost:5050/data";
    componentDidMount(){
        this.refresh();
    }
    refresh = ()=>{
        axios.get(this.dataurl).then((res)=>{
            // console.log(res);
            this.setState({
                users : res.data
            })
        }).catch(function(error){
            console.log("Error : ", error)
        })
    }
    //--------------------------------------
    editHandler = (arg)=>{
        // alert("EDIT : " + arg._id);
        axios.get(this.dataurl+"/"+arg._id).then((res)=>{
            this.setState({
                edit_firstname : res.data.firstname,
                edit_lastname : res.data.lastname,
                edit_email : res.data.email,
                edit_age : res.data.age,
                edit_id : res.data._id
            }, function(){
                this.setState({
                    showEditForm : true
                })
            })
        }).catch((err)=>{ console.log( "Error : ", err )})
    }
    deleteHandler = (arg)=>{
       // alert("DELETE : " + arg._id);
       axios.delete(this.dataurl+"/"+arg._id).then((res)=>{
           //console.log(res);
           this.refresh();
       }).catch((err)=>{ console.log(err)})
    }
    editUpdateHandler = (evt)=>{
        evt.preventDefault();
        let editUserData = {
            firstname : this.state.edit_firstname,
            lastname : this.state.edit_lastname,
            email : this.state.edit_email,
            age : this.state.edit_age,
            id : this.state.edit_id
        };
        axios.post(this.dataurl+"/"+editUserData.id,editUserData).then((res)=>{
            this.refresh();
            this.setState({
                edit_firstname : '',
                edit_lastname : '',
                edit_email : '',
                edit_age : '',
                showEditForm : false 
            })
        }).catch((error)=>{
            console.log("Error : ", error);
        })

    }
    //--------------------------------------
    ufNameChangeHandler = ( evt )=>{
        this.setState({
            firstname  : evt.target.value 
        })
    }
    ulNameChangeHandler = ( evt )=>{
        this.setState({
            lastname  : evt.target.value             
        })
    }
    uMailChangeHandler = ( evt )=>{
        this.setState({
            email  : evt.target.value             
        })
    }
    uAgeChangeHandler = ( evt )=>{
        this.setState({
            age  : evt.target.value 
        })
    }
    //----------------------------------------
    efNameChangeHandler = ( evt )=>{
        this.setState({
            edit_firstname  : evt.target.value 
        })
    }
    elNameChangeHandler = ( evt )=>{
        this.setState({
            edit_lastname  : evt.target.value             
        })
    }
    eMailChangeHandler = ( evt )=>{
        this.setState({
            edit_email  : evt.target.value             
        })
    }
    eAgeChangeHandler = ( evt )=>{
        this.setState({
            edit_age  : evt.target.value 
        })
    }
    //----------------------------------------
    showAddUser = ()=>{
        this.setState({ adduser : !this.state.adduser })
    }
    formSubmitHandler = (evt)=>{
        evt.preventDefault();
        let userData = {
            firstname : this.state.firstname,
            lastname : this.state.lastname,
            email : this.state.email,
            age : this.state.age
        };
        console.log(userData, this.dataurl);
        axios.post(this.dataurl,userData).then((res)=>{
            this.refresh();
            this.showAddUser();
            this.setState({
                firstname : '',
                lastname : '',
                email : '',
                age : ''
            })
        }).catch((error)=>{
            console.log("Error : ", error);
        })
    }
    //--------------------------------------
    render(){
        return <div className="container">
                    <h1>Users App</h1>
                    <hr/>
                    { this.state.adduser ? <form>
                    <div className="mb-3">
                        <label htmlFor="userfirstname" className="form-label">First Name : </label>
                        <input onChange={ this.ufNameChangeHandler } value={ this.state.firstname } type="text" className="form-control" id="userfirstname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="userlastname" className="form-label">Last Name : </label>
                        <input onChange={ this.ulNameChangeHandler } value={ this.state.lastname } type="text" className="form-control" id="userlastname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="usermail" className="form-label">eMail : </label>
                        <input onChange={ this.uMailChangeHandler } value={ this.state.email } type="text" className="form-control" id="usermail"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="userage" className="form-label">Age : </label>
                        <input onChange={ this.uAgeChangeHandler } value={ this.state.age } type="text" className="form-control" id="userage"/>
                    </div>
                    <button onClick={ this.formSubmitHandler } type="submit" className="btn btn-primary">Register</button>
                    </form> : <button onClick={ this.showAddUser } className="btn btn-primary">ADD User</button>}

                    {
                        this.state.showEditForm && <form>
                        <div className="mb-3">
                            <label htmlFor="eUserfirstname" className="form-label">Edit First Name : </label>
                            <input onChange={ this.efNameChangeHandler } value={ this.state.edit_firstname } type="text" className="form-control" id="eUserfirstname"/>
                        </div>
                        <div className="mb-3">
                            <label htmlFor="eUserlastname" className="form-label">Edit Last Name : </label>
                            <input onChange={ this.elNameChangeHandler } value={ this.state.edit_lastname } type="text" className="form-control" id="eUserlastname"/>
                        </div>
                        <div className="mb-3">
                            <label htmlFor="eUsermail" className="form-label">Edit eMail : </label>
                            <input onChange={ this.eMailChangeHandler } value={ this.state.edit_email } type="text" className="form-control" id="eUsermail"/>
                        </div>
                        <div className="mb-3">
                            <label htmlFor="eUserage" className="form-label">Edit Age : </label>
                            <input onChange={ this.eAgeChangeHandler } value={ this.state.edit_age } type="text" className="form-control" id="eUserage"/>
                        </div>
                        <button onClick={ this.editUpdateHandler } type="submit" className="btn btn-primary">Update User</button>
                        </form>
                    }

                    <hr/>
                    {/* <ul>
                        { this.state.users.map((user, idx)=>{
                            return <li key={ idx }>Full Name : { user.firstname+" "+user.lastname } | eMail : { user.email } | Age : { user.age}</li>
                        }) }
                    </ul> */}
                    <table className="table">
  <thead>
    <tr>
      <th scope="col">Sl #</th>
      <th scope="col">FirstName</th>
      <th scope="col">LastName</th>
      <th scope="col">eMail</th>
      <th scope="col">Age</th>
      <th scope="col">Update</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody>
    {
        this.state.users.map((user, idx)=>{
            return <tr key={ idx }>
                        <th>{ idx + 1 }</th>
                        <td>{ user.firstname }</td>
                        <td>{ user.lastname }</td>
                        <td>{ user.email }</td>
                        <td>{ user.age }</td>
                        <td>
                            <button onClick={ ()=>{ this.editHandler(user)}} className="btn btn-warning">Update</button>
                        </td>
                        <td>
                            <button onClick={ ()=>{ this.deleteHandler(user)}} className="btn btn-danger">Delete</button>
                        </td>
                    </tr>
        })
    }
  </tbody>
</table>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));
