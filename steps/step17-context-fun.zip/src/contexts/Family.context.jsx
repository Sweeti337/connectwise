import React from "react";

const FamilyContext = React.createContext();

let FamilyProvider = FamilyContext.Provider;
let FamilyConsumer = FamilyContext.Consumer;

export {FamilyProvider, FamilyConsumer};

// export default FamilyContext;