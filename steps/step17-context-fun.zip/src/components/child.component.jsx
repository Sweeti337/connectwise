import { Component } from 'react';
import { FamilyConsumer } from '../contexts/Family.context';

class ChildComp extends Component{
    render(){
        return <div  style={ { border : "1px solid black", padding: "10px", margin: "10px"} }>
                    <h1>Child Component</h1>
                    <FamilyConsumer>{(val)=>{
                        return <h2> Value is : { val }</h2>
                    }}</FamilyConsumer>
               </div>
    }
}


export default ChildComp;