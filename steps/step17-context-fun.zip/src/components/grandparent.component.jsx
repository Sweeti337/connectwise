import { Component } from 'react';
import { FamilyProvider } from '../contexts/Family.context';

import CousinComp from './cousin.component';
import ParentComp from './parent.component';

class GrandParentComp extends Component{
    render(){
        return <div style={ { border : "1px solid black", padding: "10px", margin: "10px"} }>
                    <h1>Grand Parent Component</h1>
                    <hr />
                    <FamilyProvider value="Hello">
                        <ParentComp/>
                        <CousinComp/>
                    </FamilyProvider>

{/*                     <FamilyProvider value="Hello Cousin">
                        <CousinComp/>
                    </FamilyProvider> */}
               </div>
    }
}


export default GrandParentComp;