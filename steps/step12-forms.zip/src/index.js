import { Component } from 'react';
import ReactDOM from 'react-dom';
import "./formstyle.css";

class MainApp extends Component{
    state = {
        uname : '',
        umail : '',
        uage : '',
        ageError : ''
    }
    nameChangeHandler = (evt)=>{
        this.setState({
            uname : evt.target.value
        })
    }
    mailChangeHandler = (evt)=>{
        this.setState({
            umail : evt.target.value
        })
    }
    ageChangeHandler = (evt)=>{
        this.setState({
            uage : evt.target.value
        })
    }
    registerationHandler = (evt)=>{
        evt.preventDefault();
        if(this.state.uage === ''){
            this.setAgeError("enter your age");
        }else{
            if(this.state.uage < 18){
                this.setAgeError("you are too young to joing us");
            }else if(this.state.uage > 90){
                this.setAgeError("you are old to joing us");
            }else{
                // alert("you are ready to joing us");
                this.setAgeError('')
                evt.target.submit();
            }
        }
    }
    setAgeError = (msg)=>{
        this.setState({
            ageError : msg
        })
    }
    render(){
        return <div className="container">
                    <h1>Registeration Form</h1>
                    <form onSubmit={ this.registerationHandler }>
                        <label htmlFor="username">User Name : </label>
                        <input onChange={ this.nameChangeHandler } value={ this.state.uname } name="username" type="text" id="username"/>
                        <br/>
                        <label htmlFor="useremail">User eMail : </label>
                        <input onChange={ this.mailChangeHandler } value={ this.state.umail } name="useremail" type="text" id="useremail"/>
                        <br/>
                        <label htmlFor="userage">User Age : </label>
                        <input onChange={ this.ageChangeHandler } value={ this.state.uage } name="userage" type="text" id="userage"/>
                        <span style={ { color : 'crimson' } }> { this.state.ageError } </span>
                        <br/>
                        <button className="btn btn-primary">Register</button>
                    </form>
                    <hr/>
                    <ul>
                        <li>User Name : { this.state.uname }</li>
                        <li>User Mail : { this.state.umail }</li>
                        <li>User Age : { this.state.uage }</li>
                    </ul>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));