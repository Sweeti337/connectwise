import { useEffect, useState } from "react";
import { fetchUrl } from 'fetch';

function ChildEffectHook(){
    let [ users, fetchUsers ] = useState([]);

    // Mounting
    useEffect(()=>{
        fetchUrl("https://jsonplaceholder.typicode.com/users", (error, meta, data)=>{
            if(error){
                console.log("Error : ", error);
            }else{
                fetchUsers(JSON.parse(data));
            }
        })
    },[]);


    return <div>
                <h1>Use Effect to make a AJAX call</h1>
                <ol>{
                    users.map((user)=>{
                        return <li key={ user.id }>{ user.name }</li>
                    })
                    }</ol>
            </div>
}

export default ChildEffectHook;