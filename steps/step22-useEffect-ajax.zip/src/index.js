import { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildEffectHook from './components/child.component';

class MainApp extends Component{
    render(){
        return <div className="container">
                    <h1>Users App </h1>
                    <ChildEffectHook/>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));