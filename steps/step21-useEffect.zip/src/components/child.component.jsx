import { useEffect, useState } from "react";

function ChildEffectHook(){
    let [ power, increasePower ] = useState(0);

    // Mounting
    useEffect(()=>{
        console.log("Component ChildEffectHook is mounted ");
    },[]);
    
    // Updating 
    useEffect(()=>{
        console.log("Power is updated ", power);
    },[power]);

    // UnMounting 
    useEffect(()=>{
       return ()=>{
        console.log("Component ChildEffectHook unmounted");
       }
    },[]); 


    // Mounting
    /*     
    useEffect(()=>{
        console.log("Component mounted and Power is updated ", power);
        return ()=>{
         console.log("Component ChildEffectHook unmounted")
        }
    },[power]); */

    return <div>
                <h1>Child Effect Hook | Power : { power } </h1>
                <button onClick={ ()=>{ increasePower(power+1) }}>Increase Power</button>
            </div>
}

export default ChildEffectHook;