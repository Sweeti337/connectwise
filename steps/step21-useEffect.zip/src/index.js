import { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildEffectHook from './components/child.component';

class MainApp extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    render(){
        return <div className="container">
                    <h1>Main App | Power : { this.state.power }</h1>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    {
                        this.state.power <= 5 && <ChildEffectHook/>
                    }
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));