import { Component } from 'react';
import ReactDOM from 'react-dom';
import ClickComp from './components/click.component';
import DragComp from './components/drag.component';

class MainApp extends Component{
    render(){
        return <div className="container">
                    <h1>Main App</h1>
                    <hr/>
                    <ClickComp message="Click Power" version="1001"/>
                    <hr/>
                    <DragComp message="Drag Power" version="1002"/>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));


