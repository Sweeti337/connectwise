import { Component } from 'react';
import WithPower from './withpower';

class DragComp extends Component{

    render(){
        return <div>
                    <h1>Drag Component</h1>
                    <h2>Power is : { this.props.pow }</h2>
                    <h3> Title : { this.props.title }</h3>
                    <h3> Version : { this.props.version }</h3>
                    <h3> Message : { this.props.message }</h3>
                    <div onMouseMove={ this.props.increasepower } style={ 
                        { 
                            width : "250px", 
                            height : "100px", 
                            backgroundColor : "crimson", 
                            textAlign : 'center', 
                            lineHeight : "100px", 
                            color : "whitesmoke", 
                            fontWeight : "bold", 
                            cursor : "pointer"} }>Drag Over to Increase Power</div>
               </div>
    }
}

// export default DragComp;
export default WithPower(DragComp);