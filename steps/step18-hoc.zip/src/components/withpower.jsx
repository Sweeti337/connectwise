import { Component } from "react";

let WithPower = ( OriginalComp )=> {
    // return OriginalComp
    class NewComp extends Component{
        state = {
            power : 0
        }
        increasePower = ()=>{
            this.setState((prevState)=>{
                return {
                    power : prevState.power+1
                }
            })
        }
        render(){
            return <OriginalComp { ...this.props } pow={ this.state.power } increasepower={ this.increasePower } title="Hello from Higher Order Component"/>
        }
    }

    return NewComp
}
export default WithPower;