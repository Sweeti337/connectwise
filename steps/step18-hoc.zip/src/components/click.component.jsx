import { Component } from 'react';
import WithPower from './withpower';

class ClickComp extends Component{
    
    render(){
        return <div>
                    <h1>ClickComp Component</h1>
                    <h2>Power is : { this.props.pow }</h2>
                    <h3> Title : { this.props.title }</h3>
                    <h3> Version : { this.props.version }</h3>
                    <h3> Message : { this.props.message }</h3>
                    <button onClick={ this.props.increasepower }>Increase Power</button>
               </div>
    }
}


// export default ClickComp;

export default WithPower(ClickComp);