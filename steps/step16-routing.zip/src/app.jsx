import { Component } from 'react';
import { BrowserRouter, Link, NavLink, Route, Switch } from 'react-router-dom';
import BatmanComp from './components/batman.component';
import HomeComp from './components/home.component';
import NotFoundComp from './components/notfound.component';
import SupermanComp from './components/superman.component';
import "./mystyle.css";
{/* 
<ul>
    <li><Link to="/">Home </Link></li>
    <li><Link to="/batman">Batman </Link></li>
    <li><Link to="/superman">Superman </Link></li>
    <li><Link to="/hulk">Hulk </Link></li>
    <li><Link to="/ironman">Ironman </Link></li>
</ul> */}
class MainApp extends Component{
    state = {
        power : 0
    }
    render(){
        return <div className="container">
                    <h1>Main Application</h1>
                    <input type="range" value={this.state.power} onInput={ (evt)=>{ this.setState({power : evt.target.value })} }/>
                    { this.state.power }
                    <BrowserRouter>
                        <ul>
                            <li><NavLink activeClassName="boxer" to="/" exact >Home </NavLink></li>
                            <li><NavLink activeClassName="boxer" to="/batman">Batman </NavLink></li>
                            <li><NavLink activeClassName="boxer" to={ "/superman/"+this.state.power }>Superman </NavLink></li>
                            <li><NavLink activeClassName="boxer" to="/hulk">Hulk </NavLink></li>
                            <li><NavLink activeClassName="boxer" to="/ironman">Ironman </NavLink></li>
                        </ul>
                        <hr/>
                        <Switch>
                            <Route component={ HomeComp }       path="/" exact />
                            <Route component={ BatmanComp }     path="/batman" />
                            <Route component={ SupermanComp }   path="/superman/:pow" />
                            <Route component={ SupermanComp }   path="/superman" />
                            <Route component={NotFoundComp} />
                        </Switch>
                    </BrowserRouter>
               </div>
    }
}


export default MainApp;