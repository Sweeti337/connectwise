import { Component } from 'react';

class HomeComp extends Component{
    render(){
        return <div>
                    <h1>Home Component</h1>
               </div>
    }
}


export default HomeComp;