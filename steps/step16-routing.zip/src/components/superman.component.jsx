import { Component } from 'react';

class SupermanComp extends Component{
    render(){
        return <div>
                    <h1>Superman Component</h1>
                    <h2>Power is : { this.props.match.params.pow || 0 }</h2>
               </div>
    }
}


export default SupermanComp;