import { Component } from 'react';

class ChildComp extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    render(){
        return <div>
                    <h1>Child Component</h1>
                    <h2>Power : { this.state.power }</h2>
                    <button onClick={ this.increasePower }>Increase Power</button>
               </div>
    }
}
export default ChildComp;