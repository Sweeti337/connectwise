import { useState } from "react";

function ChildStateHook(){
    let [state, increaseState] = useState({
        power : 0,
        version : 0
    });
    return <div>
                <h1>Child State Hook</h1>
                <h2>Power : { state.power }</h2>
                <h2>Version : { state.version }</h2>
                <button onClick={ ()=>{ increaseState({ ...state, power : state.power + 1 }) } }>Increase Power</button>
                <button onClick={ ()=>{ increaseState({ ...state, version : state.version + 1 }) } }>Increase Version</button>
            </div>
}

export default ChildStateHook;