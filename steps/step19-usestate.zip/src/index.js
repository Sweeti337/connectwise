import { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';
import ChildStateHook from './components/child.hook.component';

class MainApp extends Component{
    render(){
        return <div className="container">
                    <h1>Main App</h1>
                    <hr/>
                    <ChildComp/>
                    <hr/>
                    <ChildStateHook/>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));