import { Component } from 'react';

class ChildComp extends Component{
    render(){
        return <div>
                    <h1>Child Component</h1>
                    <h2>Power is : { this.props.pow }</h2>
                    <input onChange={ (evt)=>{ this.props.increaseParentPower(evt.target.value) }} type="range" />
                    <br />
                    <button onClick={ ()=>{ this.props.increaseParentPower(6) }}>Click To Increase Power to 6</button>
               </div>
    }
}


export default ChildComp;