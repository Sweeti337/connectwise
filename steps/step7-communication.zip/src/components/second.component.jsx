import { Component } from 'react';

class SecondChildComp extends Component{
    render(){
        return <div>
                    <h1>Second Child Component</h1>
                    <h3>Power is { this.props.pow }</h3>
               </div>
    }
}


export default SecondChildComp;