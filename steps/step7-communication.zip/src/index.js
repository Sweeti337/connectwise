import { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';
import SecondChildComp from './components/second.component';

class MainApp extends Component{
    state = {
        power : 0
    }
    increasePower = (num)=>{
        this.setState({
            power : num
        })
    }
    render(){
        return <div className="container">
                    <h1>Main App | Power is : { this.state.power }</h1>
                    <button onClick={ ()=>{ this.increasePower(this.state.power + 1) } }>Increase Power</button>
                    <hr/>
                    <ChildComp increaseParentPower={ this.increasePower } pow={ this.state.power }></ChildComp>
                    <hr/>
                    <SecondChildComp pow={ this.state.power }></SecondChildComp>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));
