import { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';

/*
Mounting
These methods are called in the following order when an instance of a component is being created and inserted into the DOM:
    constructor()
    static getDerivedStateFromProps()
    render()
    componentDidMount()

Updating
An update can be caused by changes to props or state. These methods are called in the following order when a component is being re-rendered:
    static getDerivedStateFromProps()
    shouldComponentUpdate()
    render()
    getSnapshotBeforeUpdate()
    componentDidUpdate()

Unmounting
This method is called when a component is being removed from the DOM:
    componentWillUnmount()

*/
class MainApp extends Component{
    state = {
        version : 2
    }
    constructor(){
        super();
        console.log("MainApp's constructor was called");
    }
    static getDerivedStateFromProps(){
        console.log("MainApp's getDerivedStateFromProps was called");
        return true
    }
    componentDidMount(){
        console.log("MainApp's componentDidMount was called");    
    }
    increaseVersion = ()=>{
        this.setState({
            version : this.state.version + 1
        })
    }
    render(){
        console.log("MainApp's render was called");
        return <div className="container">
                    <h1>Main App</h1>
                    <h2>Version : { this.state.version }</h2>
                    <button onClick={ this.increaseVersion }>Increase Version</button>
                    <hr/>
                    <ChildComp ver={ this.state.version }></ChildComp>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));