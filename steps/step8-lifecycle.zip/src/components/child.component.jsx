import { Component } from 'react';

/*
Mounting
These methods are called in the following order when an instance of a component is being created and inserted into the DOM:
    constructor()
    static getDerivedStateFromProps()
    render()
    componentDidMount()

Updating
An update can be caused by changes to props or state. These methods are called in the following order when a component is being re-rendered:
    static getDerivedStateFromProps()
    shouldComponentUpdate()
    render()
    getSnapshotBeforeUpdate()
    componentDidUpdate()

Unmounting
This method is called when a component is being removed from the DOM:
    componentWillUnmount()

*/

class ChildComp extends Component{
    state = {
        version : 0
    }
    constructor(){
        super();
        console.log("ChildComp's constructor was called");
    }
    static getDerivedStateFromProps(arg1, arg2){
        console.log("ChildComp's getDerivedStateFromProps was called");
        console.log(arg1, arg2);
        return {
            version : arg1.ver
        }
    }
    componentDidMount(){
        console.log("ChildComp's componentDidMount was called");
    }
    shouldComponentUpdate(arg1, arg2){
        console.log("ChildComp's shouldComponentUpdate was called");
        console.log(arg1, arg2);
        if(arg1.ver <= 10){
            return true;
        }else{
            return false;
        }
    }
    getSnapshotBeforeUpdate(){
        console.log("ChildComp's getSnapshotBeforeUpdate was called");
        return {}
    }
    componentDidUpdate(){
        console.log("ChildComp's componentDidUpdate was called");
    }
    componentWillUnmount(){
        console.log("ChildComp's componentWillUnmount was called");
    }
    render(){
        console.log("ChildComp's render was called");
        return <div>
                    <h1>Child Component</h1>
                    <h2>Version from parent: { this.props.ver }</h2>
                    <h2>Version from state: { this.state.version }</h2>
               </div>
    }
}


export default ChildComp;