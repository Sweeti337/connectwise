import { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    state = {
        power : 0
    }
    /*     
    constructor(){
        super();
        this.increasePower = this.increasePower.bind(this);
    } 
    */
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    rangeChange = (evt)=>{
        if(this.state.power > 100){
            alert("power maxxed out");
        }else{
            this.setState({
                power : Number( evt.target.value )
            })
        }
    }
    setPowerTo10 = (num)=>{
        this.setState({
            power : num
        })
    }
    render(){
        return <div>
                    <h1>Main App | Power is { this.state.power }</h1>
                    {
                    /* 
                    <button onClick={ this.increasePower.bind(this) }>Increase Power</button>
                    <button onClick={ this.increasePower.bind(this) }>Increase Power</button> 
                    */
                    }
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <input value={ this.state.power } onInput={ this.rangeChange } type="range"/>
                    <button onClick={ ()=>{ this.setPowerTo10(10) } }>Set Power to 10</button>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));
