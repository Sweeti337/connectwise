import { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';

class MainApp extends Component{
    state = {
        show : true
    }
    /*
    render(){
        if(this.state.show){
            return <div className="container">
            <h1>Main App</h1>
            <h2> Show value is : { this.state.show+"" }</h2>
            <button onClick={ ()=>{ this.setState({ show : !this.state.show })} }>Show / Hide</button>
            <hr/>
            <ChildComp>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum exercitationem nihil totam quaerat odit minus obcaecati qui dicta nam sint autem amet veniam, expedita impedit placeat corporis quas tempora eos?
            </ChildComp>
            </div>
        }else{
            return <div>
            <h1>The Show value was : { this.state.show + "" }</h1>
            <button onClick={ ()=>{ this.setState({ show : !this.state.show })} }>Show / Hide</button>
            </div> 
        }
    }
*/

    render(){
        return <div className="container">
                <h1>Main App</h1>
                <h2> Show value is : { this.state.show+"" }</h2>
                <button onClick={ ()=>{ this.setState({ show : !this.state.show })} }>Show / Hide</button>
                <hr/>
                {/* {
                    this.state.show ? <ChildComp>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum exercitationem nihil totam quaerat odit minus obcaecati qui dicta nam sint autem amet veniam, expedita impedit placeat corporis quas tempora eos?
                    </ChildComp> : ''
                } */}
                {
                    this.state.show && <ChildComp>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Harum exercitationem nihil totam quaerat odit minus obcaecati qui dicta nam sint autem amet veniam, expedita impedit placeat corporis quas tempora eos?
                    </ChildComp>
                }
                </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));

