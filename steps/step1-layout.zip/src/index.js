import { Component } from 'react';
import ReactDOM from 'react-dom';
import Footer from './components/footer';
import Header from './components/header';
import MainComp from './components/main';
/* 
let MainApp = function(){
    return <h1>Hello World</h1>
}; 
*/

class MainApp extends Component{
    render(){
        return <div>
                    <h1>Main App</h1>
                    <Header/>
                    <MainComp/>
                    <Footer/>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));