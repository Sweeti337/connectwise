import { Component } from 'react';

class Article extends Component{
    render(){
        return<div  style={ {border : "2px solid red", margin : '10px', fontFamily : 'arial', padding : '10px'} }>
                <h3>{ this.props.title } | version : { this.props.version * 2 }</h3>
                <p>{ this.props.children }</p>
            </div>
    }
}

export default Article;