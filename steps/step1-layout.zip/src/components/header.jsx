import { Component } from 'react';

class Header extends Component{
    render(){
        return<div style={ {border : "2px solid red", height : '100px'} }>
                <h1>Header { 'My Company ' + ' From India' }</h1>
            </div>
    }
}

export default Header;