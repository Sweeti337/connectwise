import { Component } from 'react';

class Footer extends Component{
    render(){
        return<div  style={ {border : "2px solid red", height : '50px'} }>
             <h1>Footer</h1>
             </div>
    }
}

export default Footer;