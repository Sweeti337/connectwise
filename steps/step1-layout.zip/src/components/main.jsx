import { Component } from 'react';
import Article from './article';

class MainComp extends Component{
    render(){
        return<div  style={ {border : "2px solid red" } }>
                <h1>MainComp</h1>
                <Article version={ 1001 } title={ 'Article 1' }>
                    <h3>About My Company</h3>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate placeat quis nisi animi, modi eligendi totam aliquam ullam laboriosam quo, debitis possimus deserunt, minus tenetur molestias. Placeat quidem facilis maxime?
                </Article>
                <Article version={ 2001 } title={"Article 2"}>
                    <h3>About My Company's</h3>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos non deleniti eius officia neque optio, pariatur omnis distinctio nostrum iste vero corrupti ad natus. Dolores commodi modi repellendus similique eius?
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusamus, excepturi autem? Ipsa quidem alias facilis earum expedita accusamus doloribus enim odio ratione quis est accusantium, asperiores aut. Numquam, fuga molestias.
                </Article>
            </div>
    }
}

export default MainComp;