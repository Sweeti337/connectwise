import { Component } from 'react';

class HeroList extends Component{
    state = {
        power : 0
    }
    render(){
        return <div>
                    <h1>{ this.props.title }</h1>
                    <h2>Version : { this.props.version } | Power is { this.state.power }</h2>
                    <button onClick={ ()=>{
                        this.setState({ power : this.state.power + 1 })
                    } }>Increase Power</button>
                    <ul>
                        {
                            this.props.list.map((val, idx)=> <li key={ idx }>{ val }</li> )
                        }
                    </ul>
               </div>
    }
}


export default HeroList;