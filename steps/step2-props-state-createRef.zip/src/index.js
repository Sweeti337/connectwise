import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import HeroList from './components/herolist';

class MainApp extends Component{
    newAvenger = React.createRef();

    state = {
        avengers :  ['Ironman'],
        justiceleague :  ['Batman','Wonder Women', 'Flash', 'Aquaman','Cyborg', 'Superman'],
        indicHeroes :  ['Phantom','Shaktiman', 'Krish', 'Nagaraj', 'Chacha Choudary','Rajanikanth','Rock' ]
    }
    addHeroFun(){
/*         let existingAvengers = this.state.avengers;
            existingAvengers.push('vision'); */
        this.setState({ 
            avengers : [...this.state.avengers, this.newAvenger.current.value ] 
        }); 
        this.newAvenger.current.value = '';

    }
    render(){
        return <div>
                    <h1>Main App</h1>
                    <input ref={ this.newAvenger } type="text"/>
                    <button onClick={ this.addHeroFun.bind(this)  }>Add Avenger</button>
                    <HeroList version={ 101 } title="Avengers" list={ this.state.avengers }/>
                    <HeroList version={ 102 } title="Justice League" list={ this.state.justiceleague }/>
                    <HeroList version={ 103 } title="Indic Heroes" list={ this.state.indicHeroes }/>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));