import { Component } from 'react';
import ReactDOM from 'react-dom';
import { fetchUrl } from 'fetch';

class MainApp extends Component{
    state = {
        users : []
    }
    componentDidMount(){
        
    }
    callData = ()=>{
        fetchUrl("https://jsonplaceholder.typicode.com/users", (err, meta, data)=>{
            if(err){
                console.log("Error : ", err);
            }else{
               this.setState({
                    users : JSON.parse( data )
                }) 
                // console.log(JSON.parse(data));
            }
        })
    }
    render(){
        return <div className="container">
                    <h1>Users App</h1>
                    <button onClick={ this.callData }> Get Data </button>
                    <hr/>
                    <ul>
                        { this.state.users.map((user)=>{
                            return <li key={ user.id }>{ user.name }</li>
                        }) }
                    </ul>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));
