import { Component } from 'react';
import  PropTypes from 'prop-types';

class ChildComp extends Component{
    /* 
    static defaultProps = {
        title : "Default Title",
        version : 1
    } 
    */
    static propTypes = {
        title : PropTypes.string,
        version : PropTypes.number.isRequired
    }
    render(){
        return <div>
                    <h1>ChildComp</h1>
                    <hr/>
                    <h3>Version : { this.props.version }</h3>
                    <h3>Title : { this.props.title }</h3>
                    {/* <h3>Title : { this.props.title || 'Default Title' }</h3> */}
               </div>
    }
}
/* 
ChildComp.defaultProps = {
    title : "Default Title",
    version : 1
}
 */

export default ChildComp;