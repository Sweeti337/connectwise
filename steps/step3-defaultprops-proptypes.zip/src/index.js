import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/childcomp';

class MainApp extends Component{
    render(){
        return<>
                <div>
                        <h1>Main App</h1>
                        <ChildComp version={ 10011 } title="My New Title" />
                </div>
                <div>
                        <h1>Main App</h1>
                        <ChildComp version={ 10011 } title="My New Title" />
                </div>
            </>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));