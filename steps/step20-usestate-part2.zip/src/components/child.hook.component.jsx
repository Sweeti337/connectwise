import { useState } from "react";

function ChildStateHook(){
    let [state, increaseState] = useState({
        power : 0,
        version : 0
    });
    let clickPowerHandler = ()=>{
        increaseState({
            ...state,
            power : state.power + 1
        })
    }
    let clickVersionHandler = ()=>{
        increaseState({
            ...state,
            version : state.version + 1
        })
    }
    return <div>
                <h1>Child State Hook</h1>
                <h2>Power : { state.power }</h2>
                <h2>Version : { state.version }</h2>
                <button onClick={ clickPowerHandler }>Increase Power</button>
                <button onClick={ clickVersionHandler }>Increase Version</button>
            </div>
}

export default ChildStateHook;