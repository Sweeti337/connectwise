import { useDispatch, useSelector } from "react-redux"
import { addHero } from "../redux/hero";

function HeroHookComp(){
    const numerOfHeroes = useSelector( store => store.numerOfHeroes );
    const dispatch = useDispatch();

    return <div>
                <h1> Avenger's Enrollment Program </h1>
                <h2>Number of Avengers recruited : { numerOfHeroes }</h2>
                <button onClick={ ()=>{ dispatch( addHero() ) } }>Add Avenger</button>
            </div>
}

export default HeroHookComp;