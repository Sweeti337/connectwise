import { Component } from "react";
import { addHero } from "../redux/hero";
import { connect } from 'react-redux';

const mapStateToProps = (state)=>{
    return {
        numerOfHeroes : state.numerOfHeroes
    }
}

const mapDispatchToProps = (dispatch)=>{
    return {
        addHero : ()=> dispatch( addHero() )
    }
}

class HeroComp extends Component{
    render(){
        return <div>
                <h1> Avenger's Enrollment Program </h1>
                <h2>Number of Avengers recruited : { this.props.numerOfHeroes }</h2>
                <button onClick={ this.props.addHero }>Add Avenger</button>
               </div>
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(HeroComp);