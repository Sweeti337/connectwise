import ADD_HERO from '../type/hero.type';

const initalState = {
    numerOfHeroes : 0
};

const heroReducer = (state = initalState, action)=>{
    switch(action.type){
        case ADD_HERO : return {...state, numerOfHeroes : state.numerOfHeroes + 1}
        default : return state
    }
};


export default heroReducer;