import { createStore } from 'redux';
import heroReducer from './reducer/hero.reducer';

const store = createStore( heroReducer );

export default store;