import ADD_HERO from '../type/hero.type';

// action creator
const addHero = ()=>{
    return {
        type : ADD_HERO
    }
}

export default addHero;