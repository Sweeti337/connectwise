import addHero from "./action/hero.action";

// export default addHero;
export {addHero};