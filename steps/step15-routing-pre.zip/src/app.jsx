import { Component } from 'react';
import { BrowserRouter } from 'react-router-dom';

class MainApp extends Component{
    render(){
        return <div>
                    <h1>Main Application</h1>
                    <hr/>
               </div>
    }
}


export default MainApp;