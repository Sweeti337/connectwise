import { Component } from 'react';

class SupermanComp extends Component{
    render(){
        return <div>
                    <h1>Superman Component</h1>
               </div>
    }
}


export default SupermanComp;