import { Component } from 'react';
import ReactDOM from 'react-dom';

class ChildComp extends Component{
    render(){
        return ReactDOM.createPortal( this.props.children ,document.getElementById("box")) 
    }
}

class MainApp extends Component{
    state = {
        show : false
    }
    toggleShowHide = ()=>{
        this.setState({
            show : !this.state.show
        })
    }
    render(){
        return <div className="container">
                    <h1>Main App</h1>
                    <hr/>
                    { this.state.show ? <ChildComp>
                        <div>
                            <h2>Terms and Conditions</h2>
                            <hr/>
                            <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati iusto, quae similique facere animi mollitia magni tenetur doloribus sequi dolorum porro repellendus ducimus vero maxime molestias quibusdam. Dicta, earum maxime.
                            </p>
                            <p>
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Obcaecati quo consectetur velit eos, debitis unde animi aut optio enim cum cupiditate inventore aliquid. Id rem, fugit nulla delectus maiores vitae.
                            </p>
                            <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste consequuntur, nam accusamus natus inventore impedit ratione nulla animi quae quo, minus saepe, ipsam reprehenderit dolores fuga quas commodi rerum exercitationem.
                            </p>
                            <button onClick={ this.toggleShowHide }>Hide Terms & Conditions</button>
                        </div>
                    </ChildComp> : <div>
                        <button onClick={ this.toggleShowHide }>Show Terms & Conditions</button>
                        </div>}
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));