import { Component } from 'react';
import ReactDOM from 'react-dom';
import appstyle from "./client.module.css";
import "./myfile.css";

/*
inline style
infile style
external style
application style
modules
-
css default
    sass
    scss
    less
    stylus
*/

class MainApp extends Component{
    parablock = {
        color: "white",
        fontFamily: "arial",
        width: "400px",
        backgroundColor: "red",
        textAlign: 'justify',
        fontSize: '14px',
        padding: '10px'
      };
    render(){
        return <div className="container">
                    <h1>Main App</h1>
                    <p>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur necessitatibus beatae, non voluptatibus reiciendis. Harum labore sint necessitatibus ea laboriosam earum, error et placeat ratione quo eum eveniet delectus?
                    </p>
                    <p style={ this.parablock }>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur necessitatibus beatae, non voluptatibus reiciendis. Harum labore sint necessitatibus ea laboriosam earum, error et placeat ratione quo eum eveniet delectus?
                    </p>
                    <p style={ this.parablock }>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur necessitatibus beatae, non voluptatibus reiciendis. Harum labore sint necessitatibus ea laboriosam earum, error et placeat ratione quo eum eveniet delectus?
                    </p>
                    <article className="box">
                        <h3>Article 1</h3>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur necessitatibus beatae, non voluptatibus reiciendis. Harum labore sint necessitatibus ea laboriosam earum, error et placeat ratione quo eum eveniet delectus?
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur necessitatibus beatae, non voluptatibus reiciendis. Harum labore sint necessitatibus ea laboriosam earum, error et placeat ratione quo eum eveniet delectus?
                    </article>
                    <article className={ appstyle.box }>
                        <h3>Article 2</h3>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur necessitatibus beatae, non voluptatibus reiciendis. Harum labore sint necessitatibus ea laboriosam earum, error et placeat ratione quo eum eveniet delectus?
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur necessitatibus beatae, non voluptatibus reiciendis. Harum labore sint necessitatibus ea laboriosam earum, error et placeat ratione quo eum eveniet delectus?
                    </article>
                    <article className="box">
                        <h3>Article 2</h3>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur necessitatibus beatae, non voluptatibus reiciendis. Harum labore sint necessitatibus ea laboriosam earum, error et placeat ratione quo eum eveniet delectus?
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloremque aspernatur necessitatibus beatae, non voluptatibus reiciendis. Harum labore sint necessitatibus ea laboriosam earum, error et placeat ratione quo eum eveniet delectus?
                    </article>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));