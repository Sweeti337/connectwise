import { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        /*  
        this.setState({
            power : this.state.power + 1
        });
        this.setState({
            power : this.state.power + 1
        });
        this.setState({
            power : this.state.power + 5
        });
        console.log("Power is : ", this.state.power); 
        */
       this.setState((...args) => { 
           return {
            power : args[1].pow 
           }
       }, ()=>{
           this.setState((...args)=>{ 
               return {
                   power : args[0].power + 1
               }
           },()=>{
            console.log(this.state.power)
           })
       })
        /* this.setState({
            power : this.state.power + 1
        },()=>  console.log("Power is : ", this.state.power) ); */
        /* this.setState((...args)=>{
            console.log(args[0], args[1]);
            return {
                // power : prevState.power + 1
                power : args[1].pow
            }
        }, function(){ 
            console.log("Power is : ", this.state.power); 
        }); */
    }
    render(){
        return <div>
                    <h1>Main App  </h1>
                    <h1>Power : { this.state.power }  </h1>
                    <button onClick={ this.increasePower }>Increase Power</button>
               </div>
    }
}

ReactDOM.render(<MainApp pow={5}/>, document.getElementById("root"));