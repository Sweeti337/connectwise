import { Component } from 'react';

class ChildComp extends Component{
    render(){
        console.log("ChildComp's render was called", this.props.pow, new Date().getSeconds() );
        return <div>
                    <h1>Child Component</h1>
                    <h2>Power is : { this.props.pow }</h2>
               </div>
    }
}


export default ChildComp;