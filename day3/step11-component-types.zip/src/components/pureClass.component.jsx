import { PureComponent } from 'react';

class PureChildComp extends PureComponent{
    render(){
        console.log("Pure ChildComp's render was called", this.props.pow, new Date().getSeconds() );
        return <div>
                    <h1>Pure Child Component</h1>
                    <h2>Power is : { this.props.pow }</h2>
               </div>
    }
}


export default PureChildComp;