function RegularFunComp(props){
    console.log("RegularFunComp's render was called", props.pow, new Date().getSeconds() );
    return <div>
        <h1> Regular Function Component </h1>
        <h2>Power : { props.pow }</h2>
    </div>
}

export default RegularFunComp;