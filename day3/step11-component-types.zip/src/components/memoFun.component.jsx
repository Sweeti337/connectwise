import React from 'react';

function MemoFunComp(props){
    console.log("MemoFunComp's render was called", props.pow, new Date().getSeconds() );
    return <div>
        <h1> Memo Function Component </h1>
        <h2>Power : { props.pow }</h2>
    </div>
}

export default React.memo(MemoFunComp);