import { Component } from 'react';
import ReactDOM from 'react-dom';
import PureChildComp from './components/pureClass.component';
import ChildComp from './components/regularClass.component';
import RegularFunComp from './components/regularFunction.component';
import MemoFunComp from './components/memoFun.component';

class MainApp extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    setMaxPower = ()=>{
        this.setState({
            power : 100
        })
    }
    render(){
        return <div className="container">
                    <h1>Main App</h1>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.setMaxPower }>Set Max Power</button>
                    <hr/>
                    <ChildComp pow={ this.state.power }></ChildComp>
                    <PureChildComp pow={ this.state.power }></PureChildComp>
                    <RegularFunComp pow={ this.state.power }></RegularFunComp>
                    <MemoFunComp pow={ this.state.power }></MemoFunComp>
               </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"));
